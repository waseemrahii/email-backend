// // const mongoose = require('mongoose');

// // const EmailListSchema = new mongoose.Schema({
// //     name: { type: String, required: true },
// //     emails: [{ type: String, required: true }],
// //     createdAt: { type: Date, default: Date.now }
// // });

// // module.exports = mongoose.model('EmailList', EmailListSchema);


// const mongoose = require('mongoose');

// const emailSchema = new mongoose.Schema({
//     email: {
//         type: String,
//         required: true,
//         unique: true,
//         match: /.+\@.+\..+/ // Basic email validation
//     }
// }, { timestamps: true });

// module.exports = mongoose.model('Email', emailSchema);



const mongoose = require('mongoose');

const EmailListSchema = new mongoose.Schema({
    name: { type: String, required: true },
    emails: [{ type: String, required: true }],
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('EmailList', EmailListSchema);
